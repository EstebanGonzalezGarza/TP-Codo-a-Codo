import java.util.Scanner;

class Main {
  public static void main(String[] args) {


  //Realizar un programa donde se ingresen 5 numeros e informe el promedio de los numeros ingresados.
    
  Scanner scan= new Scanner(System.in);
  
  int cantDeNumerosAIngresar= 5;
  double resultadoSuma= 0.0;
  System.out.println("Debe ingresar "+cantDeNumerosAIngresar+" numeros enteros positivos: ");
    
    for (int i=1; i<=cantDeNumerosAIngresar; i++){
      System.out.println("Su "+ i + "° numero es: ");
      double numero = scan.nextDouble();    
      resultadoSuma += numero;    
    }
  double promedio= resultadoSuma / cantDeNumerosAIngresar;
  System.out.println("El promedio de los numeros ingresados es: "+promedio);
  scan.close();
  }
}